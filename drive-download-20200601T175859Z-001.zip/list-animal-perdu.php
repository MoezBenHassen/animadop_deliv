<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{


 ?>
 <!doctype html>
<html>

<head>
	<meta charset="UTF-8">
	
	
	<title>User  |Liste Animaux </title>

  

</head>

<body>
   
    <h2>Liste Animaux perdu </h2>
	<table >
        <thead>
			<tr>
				<th>#</th>
			<th>lieu</th>
			<th>date</th>
            <th>descr</th>
           	
			<th>Action</th>
				
			</tr>
		</thead>
		<tfoot>
			<tr>
			<th>#</th>
			<th>lieu</th>
			<th>date</th>
            <th>descr</th>
           	
			<th>Action</th>
			</tr>
			
		</tfoot>
	    <tbody>

<?php $sql = "SELECT perdu.id,perdu.lieu,perdu.date,perdu.descr from perdu ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{?>	
			<tr>
				<td><?php echo htmlentities($result->id);?></td>
				<td><?php echo htmlentities($result->lieu);?></td>
	            <td><?php echo htmlentities($result->date);?></td>
                <td><?php echo htmlentities($result->descr);?></td>
                
	            <td><button>Contacter</button></td>
											
		       
			</tr>
			<?php $cnt=$cnt+1; }} ?>
										
		</tbody>
	</table>
<a href="ajouter-animal-perdu.php">Ajouter un animal perdu</a>

</body>
</html>
<?php }?>