<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:includes/login.php');
}
else{

if(isset($_POST['submit']))
  {
    $lieu=$_POST['lieu'];
    $date=$_POST['date'];
    $descr=$_POST['descr'];
    
   

$sql1="SELECT id from utilisateur where id=animal.id_user ";
$query1 = $dbh->prepare($sql1);
$id=$_POST['id'];
$query1->bindParam(':id',$id,PDO::PARAM_STR);
$sql="INSERT INTO perdu(lieu,date,descr) VALUES(:lieu ,:date,:descr)";
$query = $dbh->prepare($sql);
$query->bindParam(':lieu',$lieu,PDO::PARAM_STR);
$query->bindParam(':date',$date,PDO::PARAM_STR);
$query->bindParam(':descr',$descr,PDO::PARAM_STR);
$query->bindParam(':img',$img,PDO::PARAM_STR);


$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Article added successfully";
}
else 
{
$error="Something went wrong. Please try again";
}

}


	?>
<!doctype html>
<html >

<head>
	<meta charset="UTF-8">

	

</head>

<body>
	<?php include('includes/header.php');?>
	
	<?php include('includes/leftbar.php');?>
		
					
						<h2 >Ajouter animal</h2>

					
									<div >Basic Info</div>
<?php if($error){?><div ><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div ><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

<form method="post"  enctype="multipart/form-data">

<label >lieu</label>

<input type="date" name="name"  required>

<label >date</label>

<input type="text"  name="race"  required>

<label >descr</label>

<input type="text" name="sexe"  required>







	
								
	<button type="reset">Cancel</button>
	<button name="submit" type="submit">Save changes</button>
</form>
</body>
</html>
<?php }?>