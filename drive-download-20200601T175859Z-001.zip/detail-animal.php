<?php 
session_start();
include('includes/config.php');
error_reporting(0);
?>
 <!doctype html>
<html>

<head>
	<meta charset="UTF-8">
	
	
	<title>User  |  Detail-animal </title>

  

</head>

<body>
   
<?php 
$id=intval($_GET['vhid']);

$sql = "SELECT * from animal where id=:vhid ";
$query = $dbh -> prepare($sql);
$query->bindParam(':vhid',$id, PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{  

?>  

 <div><img src="img/animal/<?php echo htmlentities($result->img);?>"   alt="image" ></div>
 <p>nom.sexe</p>
 <h2><?php echo htmlentities($result->nome);?> , <?php echo htmlentities($result->sexe);?></h2>
 <p>Race</p>
 <h2><?php echo htmlentities($result->race);?></h2>
 <p>description</p>
 <h2><?php echo htmlentities($result->description);?></h2>
 <button>Contacter</button>









</body>
</html>
<?php }}?>
