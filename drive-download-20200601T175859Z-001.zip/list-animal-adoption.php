<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{


 ?>
 <!doctype html>
<html>

<head>
	<meta charset="UTF-8">
	
	
	<title>User  |Liste Animaux </title>

  

</head>

<body>
   
    <h2>Liste Animaux a adopter </h2>
	<table >
        <thead>
			<tr>
				<th>#</th>
				<th>Nom</th>
				<th>Sexe </th>
                <th>Famille</th>
                <th>Utilisateur</th>
				<th>Race</th>
				<th>Action</th>
				
			</tr>
		</thead>
		<tfoot>
			<tr>
			<th>#</th>
			<th>Nom</th>
			<th>Sexe </th>
            <th>Famille</th>
            <th>Utilisateur</th>
			<th>Race</th>	
			<th>Action</th>
			</tr>
			
		</tfoot>
	    <tbody>

<?php $sql = "SELECT animal.id,animal.img,animal.nome,animal.sexe,animal.famille,utilisateur.prenom,utilisateur.nom,animal.race,animal.id_user from animal,utilisateur where animal.id_user=utilisateur.id and animal.famille='adoption'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{?>	
			<tr>
				<td><?php echo htmlentities($result->img);?><img src="img/animal/<?php echo htmlentities($result->img);?>"  alt="Image" /></td>
				<td><?php echo htmlentities($result->nome);?></td>
	            <td><?php echo htmlentities($result->sexe);?></td>
                <td><?php echo htmlentities($result->famille);?></td>
                <td><?php echo htmlentities($result->prenom);echo " " ;echo htmlentities($result->nom);?></td>
	            <td><?php echo htmlentities($result->race);?></td>
	            <td><a href="detail-animal.php?vhid=<?php echo $result->id;?>" class="btn">Details</a></td>
											
		       
			</tr>
			<?php $cnt=$cnt+1; }} ?>
										
		</tbody>
	</table>
<a href="ajouter-animal-accouplment.php">Ajouter un animal a l'adoption</a>

</body>
</html>
<?php }?>